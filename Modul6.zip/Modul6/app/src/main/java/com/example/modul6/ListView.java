package com.example.modul6;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ListView extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item);
    }
}
